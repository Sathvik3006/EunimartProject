
import './App.css';
import HomePage from './components/HomePage/HomePage';
import UserDetails from './components/UserDetails/UserDetails';

import { BrowserRouter as Router,Route,Routes } from 'react-router-dom'
function App() {
  return (
    <div className="App">
     
      <div>
        <Router>
        <Routes>
       
          <Route exact path='/' element={<HomePage/>}></Route>
          <Route exact path='/users' element={<HomePage/>}></Route>
          <Route exact path='/users/:userid' element={<UserDetails/>} ></Route>
          </Routes>
        </Router></div>
     

    </div>
  );
}

export default App;
