import React, { Component } from 'react'
import axios from "axios"
import { Link } from 'react-router-dom'

export default class HomePage extends Component {
    constructor(props){
      super(props);
      this.state={
          user_details:[]

      }
     
    }
    async componentDidMount(){
        let response = await axios.get("https://reqres.in/api/users")
       console.log(response,response.data,response.data.data)
       const details=response.data.data;
       this.setState({
           user_details:details
       },()=> console.log("state",this.state.user_details))

      
      
    }
  render() {
    return (
      <>
      <br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br>
      <div style={{display:'flex',flexDirection:'row'}}>
          {this.state.user_details.map((user)=>{
              return <div key={user.id} style={{border:'2px solid',width:'300px',margin:'10px'}}>
                
                 <Link to={`/users/${user.id}`}><img src={user.avatar}></img></Link>
                 <div><b>Name : </b>{user.first_name} {user.last_name}</div>
              </div>
          })}
      </div>
      <br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br>
      </>
    )
  }
}
