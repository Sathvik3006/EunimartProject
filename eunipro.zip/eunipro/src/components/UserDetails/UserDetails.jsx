import React, { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import axios from "axios"
export default function UserDetails() {
    const [userDetails, setUserDetails] = useState([]);
    const params = useParams();
    useEffect(() => {

        let response = axios.get("https://reqres.in/api/users").then((res) => {
            const details = res.data.data;
            console.log(res)
            setUserDetails(details);
        })
        console.log(userDetails, params.userid)
    }, [])
    return (
        <>
        <br></br><br></br>
        <div  style={{height:'50px',textAlign:'left'}}> <Link to={`/users`}><button><img src='https://www.rawshorts.com/freeicons/wp-content/uploads/2017/01/blue_repicthousebase_1484336386-1.png' style={{width:'20px',height:'20px'}}></img>Home</button></Link></div>
        <br></br><br></br><br></br>
        <div style={{ display: 'flex', flexDirection: 'row' }}>
            
            {
                userDetails.map((user) => {
                    if (user.id == params.userid) {
                        return <div key={user.id} style={{ border: '2px solid', width: '300px', margin: '10px' }} >
                            <div><Link to={`/users/${user.id}`}><img src={user.avatar}></img></Link></div>
                            {
                                <div>
                                    <div><b>Email Id : </b>{user.email}</div>
                                    <div><b>First Name : </b>{user.first_name}</div>
                                    <div><b>Last Name : </b>{user.last_name}</div>


                                </div>
                            }
                        </div>
                    }
                    else {



                        return <div key={user.id} style={{ border: '1px solid', width: '200px', margin: '10px' }} >
                            <div><Link to={`/users/${user.id}`}><img src={user.avatar}></img></Link></div>

                        </div>
                    }
                })

            }
        </div>
        <br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br>
        </>
    )
}
